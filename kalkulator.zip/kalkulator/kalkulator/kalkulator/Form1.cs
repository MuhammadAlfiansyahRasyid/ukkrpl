﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace kalkulator
{
    public partial class Form1 : Form
    {
        decimal bil1;
        decimal bil2;
        int opr;
        Boolean opr_selesai = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "1";
            }
            else
            {
                txtdis1.Text += "1";
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "2";
            }
            else
            {
                txtdis1.Text += "2";
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "3";
            }
            else
            {
                txtdis1.Text += "3";
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "4";
            }
            else
            {
                txtdis1.Text += "4";
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "5";
            }
            else
            {
                txtdis1.Text += "5";
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "6";
            }
            else
            {
                txtdis1.Text += "6";
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "7";
            }
            else
            {
                txtdis1.Text += "7";
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "8";
            }
            else
            {
                txtdis1.Text += "8";
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "9";
            }
            else
            {
                txtdis1.Text += "9";
            }
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text == "0")
            {
                txtdis1.Text = "0";
            }
            else
            {
                txtdis1.Text += "0";
            }
        }

        private void btnx_Click(object sender, EventArgs e)
        {
            bil1 = Convert.ToDecimal(txtdis1.Text);
            txtdis2.Text = "X";
            txtdis1.Text = "";
            opr = 1;
            opr_selesai = true;
        }

        private void btnbagi_Click(object sender, EventArgs e)
        {
            bil1 = Convert.ToDecimal(txtdis1.Text);
            txtdis2.Text = "/";
            txtdis1.Text = "";
            opr = 2;
            opr_selesai = true;
        }

        private void btntambah_Click(object sender, EventArgs e)
        {
            bil1 = Convert.ToDecimal(txtdis1.Text);
            txtdis2.Text = "+";
            txtdis1.Text = "";
            opr = 3;
            opr_selesai = true;
        }

        private void btnkurang_Click(object sender, EventArgs e)
        {
            bil1 = Convert.ToDecimal(txtdis1.Text);
            txtdis2.Text = "-";
            txtdis1.Text = "";
            opr = 4;
            opr_selesai = true;
        }

        private void btnsd_Click(object sender, EventArgs e)
        {
            if (opr_selesai == true)
                bil2 = Convert.ToDecimal(txtdis1.Text);
            {
                switch (opr)
                { 
                  case 1:
                    txtdis1.Text = Convert.ToString(bil1 * bil2);
                    break;
                  case 2:
                    txtdis1.Text = Convert.ToString(bil1 / bil2);
                    break;
                  case 3:
                    txtdis1.Text = Convert.ToString(bil1 + bil2);
                    break;
                  case 4:
                   txtdis1.Text = Convert.ToString(bil1 - bil2);
                   break;
               }
           }
       
        }

        private void btnc_Click(object sender, EventArgs e)
        {
            txtdis1.Text = "0";
            bil1 = 0;
            bil2 = 0;
            txtdis2.Text = "";

        }

        private void btnhapus_Click(object sender, EventArgs e)
        {
            txtdis1.Text = txtdis1.Text.Remove(txtdis1.Text.Length - 1);
            if ((txtdis1.Text == "") || (txtdis1.Text == "-"))
            {
                txtdis1.Text = "0";
            }
        }

        private void btnkoma_Click(object sender, EventArgs e)
        {
            if (txtdis1.Text.Contains(',') == false)
            {
                txtdis1.Text = txtdis1.Text + ",";
            }
        }
    }
}


